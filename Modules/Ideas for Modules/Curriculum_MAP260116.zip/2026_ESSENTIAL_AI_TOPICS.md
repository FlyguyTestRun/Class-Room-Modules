# 2026 AI Curriculum - ESSENTIAL TOPICS

**What every AI professional must know by end of 2026**

---

## PART A: FOUNDATIONS (Everyone)

### 1. LLM Fundamentals
- **Transformers:** Attention is all you need (high-level, not math)
- **Scaling laws:** More parameters & data = better (Chinchilla optimal)
- **Context windows:** Token limitations, what you can fit
- **Multi-modal:** Text+image+audio models (Claude, GPT-4V, etc.)
- **Open vs. Closed:** Open-source (Llama, Mistral) vs. API (Claude, GPT-4)

### 2. Prompt Engineering
- **Basics:** System prompt, few-shot, chain-of-thought
- **Advanced:** Prompt injection, jailbreaks, defense
- **Optimization:** A/B testing, metrics, iteration
- **Cost reduction:** Fewer tokens, batch processing, model selection

### 3. Retrieval-Augmented Generation (RAG)
- **Why:** LLMs hallucinate, RAG adds factual grounding
- **How:** Embeddings, vector DB, retrieval, ranking
- **Advanced:** Hybrid search, multi-hop, reranking
- **When:** When to use vs. fine-tuning

### 4. Agentic AI
- **What:** AI agents that take actions (not just generate text)
- **Tools:** Function calling, tool use, integrations
- **Reasoning:** ReAct (reasoning + acting), planning
- **Production:** Memory, multi-agent coordination
- **Real use:** Customer support bots, workflow automation

### 5. Data & Data Engineering
- **Pipelines:** ETL, data quality, governance
- **Modern stack:** Warehouse (Snowflake, BigQuery), lakes, mesh
- **Real-time:** Streaming, event-driven, Kafka/Pub-Sub
- **Unstructured data:** PDFs, images, video processing

### 6. AI Safety & Governance
- **Bias & fairness:** Detecting, mitigating bias in models
- **Hallucinations:** Why they happen, defense strategies
- **Privacy:** GDPR, PII, data anonymization
- **Security:** Prompt injection, adversarial attacks
- **Compliance:** HIPAA, SOC2, industry regulations
- **Ethics:** Responsible AI principles, stakeholder alignment
- **Frameworks:** NIST AI RMF, ISO 42001

### 7. Business & ROI
- **Use case selection:** What AI can/can't do, realistic ROI
- **Cost modeling:** API costs, infrastructure, compute
- **Change management:** Adopting AI, team dynamics
- **Competitive advantage:** What AI unlocks for your company

---

## PART B: ENGINEERING (Junior → Senior)

### 8. Model Selection & Evaluation
- **Benchmarks:** How to compare models (MMLU, HumanEval, etc.)
- **Evaluation metrics:** When to use accuracy vs. F1 vs. BLEU
- **Tradeoffs:** Speed vs. quality, cost vs. capability
- **Fine-tuning ROI:** When to fine-tune vs. prompt vs. RAG
- **Open source:** When viable, costs, operational burden

### 9. Production ML/LLM Systems
- **Serving:** Model serving (vLLM, TensorRT), optimization
- **Latency:** Reducing inference time (quantization, distillation)
- **Cost optimization:** Batch processing, model selection, caching
- **Monitoring:** Drift detection, performance degradation
- **A/B testing:** Experimentation frameworks, statistical significance

### 10. Data Quality & Feature Engineering
- **Quality metrics:** Completeness, freshness, validity
- **Feature stores:** Tecton, Feast (managing features at scale)
- **Unstructured data:** Chunking strategies, metadata extraction
- **Real-time features:** Streaming, low-latency computation
- **Data governance:** Lineage, versioning, access control

### 11. CI/CD & DevOps for AI
- **GitOps:** Infrastructure as code, declarative deployments
- **Containerization:** Docker, multi-stage builds
- **Orchestration:** Kubernetes basics, Helm
- **Deployments:** Blue-green, canary, feature flags
- **Testing:** Unit, integration, E2E, smoke tests
- **Monitoring:** Logs, metrics, traces, alerts, SLOs

### 12. Multi-Model Systems
- **Ensemble methods:** When to use multiple models
- **Routing:** Smart model selection (cost, latency, accuracy)
- **Fallback:** If model fails, what's the backup?
- **SLA management:** Guarantees on latency, accuracy, cost
- **Real examples:** Routing to Claude vs. GPT vs. Llama

### 13. Vector Databases & Search
- **Types:** Pinecone, Weaviate, Milvus, FAISS
- **Operations:** Index, search, update, delete at scale
- **Optimization:** Chunking, metadata filtering, hybrid search
- **Cost:** Storage, compute, query costs per operation
- **Alternatives:** SQL with embeddings, graph DBs

### 14. Specialized Models & Techniques
- **Vision models:** DALL-E, Stable Diffusion, vision transformers
- **Embedding models:** Sentence transformers, domain-specific embeddings
- **Specialized models:** Domain-specific fine-tuned models
- **Distillation:** Small fast models from large ones
- **Quantization:** Smaller, faster inference (8-bit, 4-bit, 1-bit)

---

## PART C: ADVANCED SYSTEMS (Architects, Tech Leads)

### 15. Agentic Systems at Scale
- **Memory:** Long-term, short-term, persistent memory architectures
- **Planning:** Multi-step planning, goal decomposition
- **Multi-agent:** Coordination, collaboration, competition
- **Evaluation:** How to evaluate agents (success rate, cost, latency)
- **Production patterns:** Frameworks (AutoGen, Crewai, LangGraph)

### 16. Large-Scale Data Architecture
- **Data mesh:** Decentralized data ownership, domain-driven
- **Real-time:** Event streaming, complex event processing
- **Governance:** Data lineage, quality SLAs, access control
- **Cost optimization:** Query optimization, partitioning, caching
- **Security:** Encryption, audit trails, PII handling

### 17. Prompt Management at Scale
- **Version control:** Tracking prompt changes, A/B testing
- **Evaluation:** Automated evaluation, human-in-the-loop
- **Governance:** Who can change prompts? Approval workflows
- **Optimization:** Prompt injection defense, cost reduction
- **Tools:** Prompt registries (Weights & Biases, LangSmith, Arize)

### 18. Cost Optimization & FinOps
- **Cost attribution:** Per user, per feature, per model
- **Token optimization:** Caching, batching, compression
- **Infrastructure:** Reserved instances, spot pricing, auto-scaling
- **ROI tracking:** Cost per user, cost per transaction
- **Real examples:** "Our RAG costs $0.02/query vs. $1 before optimization"

### 19. Security, Compliance & Governance
- **Threat model:** Common attacks (prompt injection, SSRF, data extraction)
- **Defense:** Input validation, rate limiting, output filtering
- **Compliance:** HIPAA, SOC2, FedRAMP requirements
- **Audit:** Logging, access control, change tracking
- **Incident response:** When things go wrong, how to recover

### 20. Observability & Production Readiness
- **Observability:** Logs, metrics, traces, profiles (Datadog, New Relic, Grafana)
- **Alerts:** When to alert, what thresholds, on-call rotations
- **SLOs:** Service level objectives (99.9% uptime, etc.)
- **Debugging:** Root cause analysis, error analysis
- **Post-mortems:** Blameless analysis, continuous improvement

### 21. Emerging Patterns (2026 Frontier)
- **Speculative decoding:** Faster inference via speculation
- **Mixture of experts:** Sparse models, expert routing
- **Multimodal systems:** Combining text, image, video, audio
- **Reasoning models:** O1 and similar, longer thinking time
- **Local execution:** On-device models, privacy-preserving inference
- **Knowledge distillation:** Efficient small models
- **Continual learning:** Systems that learn over time

---

## PART D: BUSINESS & CONSULTING

### 22. Customer Assessment & ROI
- **Readiness frameworks:** Is a company ready for AI?
- **ROI models:** How to calculate financial impact
- **Risk assessment:** Technical, organizational, financial risks
- **Competitive analysis:** What AI unlocks vs. competitors
- **Vendor evaluation:** Choosing between platforms, models, services

### 23. Implementation & Change Management
- **Project management:** Phased rollouts, MVP, iteration
- **Stakeholder alignment:** Getting buy-in from executives, teams
- **Risk mitigation:** Rollback plans, monitoring, fail-safes
- **Organizational change:** Training, role changes, culture shift
- **Success metrics:** KPIs, tracking progress, communicating wins

### 24. Industry-Specific Applications
**Pick 1-2 industries to deepen:**
- **Healthcare:** Clinical NLP, HIPAA, diagnostic support
- **Finance:** Fraud detection, risk modeling, compliance
- **Retail:** Personalization, demand forecasting, recommendations
- **Legal:** Document review, contract analysis, due diligence
- **Manufacturing:** Predictive maintenance, quality control, optimization

---

## PART E: EMERGING 2026 LANDSCAPE

### 25. Model Landscape (Jan 2026 & Beyond)
- **Frontier models:** Claude 3.5+, GPT-4.5+, Gemini 2.0+
- **Open source:** Llama 4.0, Mistral, specialized models
- **Multimodal:** Video understanding, reasoning across modalities
- **Reasoning:** Models with extended thinking, planning
- **Long context:** 100K+ context windows becoming standard
- **Specialized:** Domain-specific models (medical, legal, code)

### 26. Infrastructure 2026
- **Model serving:** vLLM, TensorRT, specialized hardware
- **Edge AI:** On-device models, privacy-preserving
- **Cost:** GPU/TPU pricing trends, alternatives (inference APIs)
- **Latency:** Sub-100ms inference, optimization techniques
- **Scaling:** How to scale from 1 request/sec to 1M requests/sec

### 27. Tools & Frameworks (2026 Recommended)
**LLM/RAG Development:**
- LangChain, LlamaIndex, Vercel AI SDK
- LangGraph (agent frameworks)
- Prompt management: LangSmith, Arize, Weights & Biases

**Evaluation & Testing:**
- Promptfoo, RAGAS, Arize
- Automated evaluation, human-in-the-loop

**Deployment:**
- Docker, Kubernetes, GitHub Actions
- AWS Lambda, Google Cloud Run, Azure Container Apps
- Modal, Hugging Face Spaces (managed)

**Monitoring:**
- Datadog, New Relic, Grafana + Prometheus
- LLM-specific: Arize, Weights & Biases, Langsmith

**Data:**
- Warehouse: Snowflake, BigQuery, Redshift
- Vector DB: Pinecone, Weaviate, Milvus, pgvector (Postgres)
- Feature store: Tecton, Feast

**MLOps:**
- Model registry: MLflow, Hugging Face Hub
- Orchestration: Airflow, Prefect, Dagster
- Training: Ray, Kubeflow

### 28. Security & Safety in 2026
- **LLM security:** Evolved prompt injection, jailbreaks
- **Data privacy:** GDPR enforcement, privacy-preserving inference
- **Model robustness:** Adversarial attacks, model drift
- **Supply chain:** Third-party model/data safety
- **Responsible AI:** Bias detection, fairness audits

---

## CURRICULUM MAPPING

**How These Topics Map to CoreSkills4ai Tracks:**

| 2026 Topic | Track 1 | Track 2 | Track 3 | Track 4 | Specialization |
|-----------|--------|--------|--------|--------|---|
| 1. LLM Fundamentals | ✓ | ✓ | ✓ | - | - |
| 2. Prompt Engineering | ✓ | ✓ | ✓ | ✓ | E |
| 3. RAG | - | ✓ | ✓ | ✓ | A |
| 4. Agentic AI | - | ✓ | ✓ | ✓ | A |
| 5. Data & Engineering | - | ✓ | ✓ | - | B |
| 6. AI Safety & Governance | ✓ | - | ✓ | ✓ | - |
| 7. Business & ROI | ✓ | - | - | ✓ | - |
| 8. Model Selection | - | ✓ | ✓ | ✓ | - |
| 9. Production ML/LLM | - | ✓ | ✓ | ✓ | D |
| 10. Data Quality | - | ✓ | ✓ | - | B |
| 11. CI/CD & DevOps | - | ✓ | ✓ | - | D |
| 12. Multi-Model Systems | - | ✓ | ✓ | - | A |
| 13. Vector DB & Search | - | ✓ | ✓ | - | B |
| 14. Specialized Models | - | ✓ | ✓ | ✓ | D |
| 15. Agentic at Scale | - | - | ✓ | ✓ | A |
| 16. Data Architecture | - | - | ✓ | - | B |
| 17. Prompt Management | - | ✓ | ✓ | ✓ | E |
| 18. Cost Optimization | - | ✓ | ✓ | ✓ | D |
| 19. Security & Compliance | ✓ | - | ✓ | ✓ | - |
| 20. Observability | - | ✓ | ✓ | - | D |
| 21. Emerging Patterns | - | - | ✓ | ✓ | Varies |
| 22. Customer Assessment | - | - | - | ✓ | - |
| 23. Implementation | ✓ | - | - | ✓ | - |
| 24. Industry-Specific | - | - | - | ✓ | C |

**Specializations:**
- **A:** Agentic Evaluation & Deployment
- **B:** Data Architecture for AI
- **C:** Industry-Specific (Healthcare, Finance, etc.)
- **D:** MLOps/LLMOps
- **E:** Prompt Engineering at Scale

---

## STUDENT CHECKLIST: "By End of 2026, I Can..."

After completing CoreSkills4ai, students should be able to:

### Foundations Track
- [ ] Explain why AI matters to a business
- [ ] Identify realistic vs. hype-driven AI use cases
- [ ] Write effective prompts and measure quality
- [ ] Recognize AI bias and governance needs
- [ ] Design a simple AI workflow

### Engineering Track
- [ ] Call LLM APIs and handle errors
- [ ] Build an ETL pipeline for AI
- [ ] Evaluate and optimize prompts
- [ ] Build a RAG system (retrieval + generation)
- [ ] Write unit tests and evaluate AI systems
- [ ] Deploy AI app to production (serverless or K8s)

### Enterprise Track
- [ ] Design agentic systems (multi-step reasoning)
- [ ] Design modern data architecture for AI
- [ ] Build ML/LLM pipelines and monitoring
- [ ] Route requests across multiple models
- [ ] Optimize cost and latency
- [ ] Implement CI/CD for AI systems
- [ ] Set up observability and alerting
- [ ] Design secure, compliant AI systems

### Consulting Track
- [ ] Assess company readiness for AI
- [ ] Calculate ROI and business cases
- [ ] Align stakeholders and manage change
- [ ] Mitigate risk and governance
- [ ] Select vendors and platforms
- [ ] Deliver and manage AI projects

---

## HOW TO USE THIS

This checklist is a **teaching reference**. Each item maps to specific modules/labs.

**For instructors:** Use to design assessments.  
**For students:** Track progress and identify gaps.  
**For marketing:** Use as "course outcomes" on the website.

